import sys, pygame

pygame.init()

window = pygame.display.set_mode((371, 314))
image = pygame.image.load('brownman.png')
frame = -1
row = 0
clock = pygame.time.Clock()

while True:
    pygame.event.get()

    window.fill((255, 255, 255))
    frame += 1;
    if frame == 4:
        row += 1
    if frame > 7:
        frame = 0
        row = 0

    window.blit(image, (0, 0), ((frame%4)*371, row*314, 371, 314))
    pygame.display.update()
    clock.tick(15)
